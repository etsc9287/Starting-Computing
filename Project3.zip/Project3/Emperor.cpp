#include "Emperor.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

Emperor::Emperor(){
    
    name = "";
    health = 0;
    lightsaber_offense = 0;
    lightsaber_defense = 0;
    force_offense = 0;
}

Emperor::Emperor(string name, double health, int lightsaber_offense, int force_offense, int lightsaber_defense){
    
    name = name;
    health = health;
    lightsaber_offense = lightsaber_offense;
    force_offense = force_offense;
    lightsaber_defense = lightsaber_defense;
}

string Emperor::getName(){
    
    return name;
}

void Emperor::setName(string name){
    
    name = name;
}

int Emperor::getHealth(){
    
    return health;
}

void Emperor::setHealth(int health){
    
    health = health;
}

int Emperor::getLightsaberOffense(){
    
    return lightsaber_offense;
}

void Emperor::setLightsaberOffense(int lightsaber_offense){
    
    lightsaber_offense = lightsaber_offense;
}

int Emperor::getForceOffense(){
    
    return force_offense;
}

void Emperor::setForceOffense(int force_offense){
    
    force_offense = force_offense;
}

int Emperor::getLightsaberDefense(){
    
    return force_offense;
}

void Emperor::setLightsaberDefense(int lightsaber_defense){
    
    lightsaber_defense = lightsaber_defense;
}