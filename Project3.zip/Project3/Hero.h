#ifndef Hero_H
#define Hero_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>
using namespace std;

class Hero {
    
    private:
    
        string name;
        double health;
        int lightsaber_offense;
        int lightsaber_defense;
        int force_offense;
        StormTrooper blast_power[3];
    
    public:
    
        Hero();
        Hero(string name, double health, int lightsaber_offense, int force_offense, int lightsaber_defense);
        string getName();
        int getHealth();
        int getLightsaberOffense();
        int getLightsaberDefense();
        int getForceOffense();
        void setName(string name);
        void setHealth(double health);
        void setLightsaberOffense(int lightsaber_offense);
        void setLightsaberDefense(int lightsaber_defense);
        void setForceOffense(int force_offense);
        int lightsaberAttack(string attack_type);
        int forceAttack(string force_type);
        int noAttack();
        int lightsaberDefend(string defend_type);
        int noDefend();
};

#endif