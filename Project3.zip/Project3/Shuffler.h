#ifndef Shuffler_H
#define Shuffler_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>
using namespace std;

class Shuffler {
    
    private:
        
        int const size = 4;
        int code[4]; //random order of numbers 1-4
        
    public:
    
        Shuffler();
        Shuffler(int code[], int size);
        int getCode();
        int getsizeCode();
        void sortCode(string fileName);
};

#endif