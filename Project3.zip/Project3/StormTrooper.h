#ifndef StormTrooper_H
#define StormTrooper_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>
using namespace std;

class StormTrooper {
    
    private: 
    
        string name;
        double health;
        int blast_power;
        
    public:
    
        StormTrooper();
        StormTrooper(string name, double health, int blast_power);
        string getName();
        double getHealth();
        int getBlastPower();
        void setName(string name);
        void setHealth(double health);
        void setBlastPower(int blast_power);
};

#endif