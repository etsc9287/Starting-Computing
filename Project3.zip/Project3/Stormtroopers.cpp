#include "StormTrooper.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

StormTrooper::StormTrooper(){
    
    name = "";
    health = 0;
    blast_power = 0;
}

StormTrooper::StormTrooper(string name, double health, int blast_power){
    
    name = name;
    health = health;
    blast_power = blast_power;
}

string StormTrooper::getName(){
    
    return name;
}

void StormTrooper::setName(string name){
    
    name = name;
}

int StormTrooper::getHealth(){
    
    return health;
}

void StormTrooper::setHealth(int health){
    
    health = health;
}

int StormTrooper::getBlastPower(){
    
    return blast_power;
}

void StormTrooper::setBlastPower(int blast_power){
    
    blast_power = blast_power;
}
