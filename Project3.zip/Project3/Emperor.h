#ifndef Emperor_H
#define Emperor_H
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <math.h>
using namespace std;

class Emperor {
    
    private:
    
        string name;
        double health;
        int lightsaber_offense;
        int lightsaber_defense;
        int force_offense;
        
    public:
    
        Emperor();
        Emperor(string name, double health, int lightsaber_offense, int force_offense, int lightsaber_defense);
        string getName();
        double getHealth();
        int getLightsaberOffense();
        int getLightsaberDefense();
        int getForceOffense();
        void setName(string name);
        void setHealth(double health);
        void setLightsaberOffense(int lightsaber_offense);
        void setLightsaberDefense(int lightsaber_defense);
        void setForceOffense(int force_offense);
};

#endif