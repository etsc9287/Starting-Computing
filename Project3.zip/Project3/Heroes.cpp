#include "Hero.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <vector>
#include <string>
using namespace std;

Hero::Hero(){
    
    name = "";
    health = 0;
    lightsaber_offense = 0;
    lightsaber_defense = 0;
    force_offense = 0;
}

Hero::Hero(string name, double health, int lightsaber_offense, int force_offense, int lightsaber_defense){
    
    name = name;
    health = health;
    lightsaber_offense = lightsaber_offense;
    force_offense = force_offense;
    lightsaber_defense = lightsaber_defense;
}

string Hero::getName(){
    
    return name;
}

void Hero::setName(string name){
    
    name = name;
}

int Hero::getHealth(){
    
    return health;
}

void Hero::setHealth(int health){
    
    health = health;
}

int Hero::getLightsaberOffense(){
    
    return lightsaber_offense;
}

void Hero::setLightsaberOffense(int lightsaber_offense){
    
    lightsaber_offense = lightsaber_offense;
}

int Hero::getForceOffense(){
    
    return force_offense;
}

void Hero::setForceOffense(int force_offense){
    
    force_offense = force_offense;
}

int Hero::getLightsaberDefense(){
    
    return force_offense;
}

void Hero::setLightsaberDefense(int lightsaber_defense){
    
    lightsaber_defense = lightsaber_defense;
}

int Hero::lightsaberAttack(string attack_type){
    
    //1. This function will activate if the user chooses to attack with a lightsaber
    //2. user can choose what type of saber attack (stab or slice), passed in parameter
    //3. Random probability will determine whether stab/slice is successful.  One option will randomly be better.
    //4. health taken from enemy if successful attack = lightsaber offense
    //returns health taken away from enemy (int)
}

int Hero::forceAttack(string force_type){
    
    //1. This function will activate if the user chooses to attack with the force
    //2. user can choose what type of force attack (crush or push), passed in parameter
    //3. Random probability will determine whether crush/push is successful.  One option will randomly be better.
    //4. health taken from enemy if successful attack = force offense
    //returns health taken away from enemy (int)
}

int Hero::noAttack(){
    
    //1. This function will activate if the user chooses not to attack at all
    //2. Random probability will determine how much health the hero gains, if at all 
    //returns possible health gained by hero for saving energy (int)
}

int Hero::lightsaberDefend(string block_type){
    
    //1. This function will activate if the user chooses to defend
    //2. user can choose what type of block (left, center, or right), passed in parameter
    //3. random probability will determine which block is successful.  
    //4. health taken away from hero = blaster power from stormtrooper class
    //returns health taken away from hero, or health taken away from enemy if block is successful
}

int Hero::noDefend(){
    
    //1. This function will activate if the user chooses not to defend
    //2. Random probbility will determine if enemy attack hits the hero.  If it does, return lost health.
    //   If it doesn't, return possible health gained by hero for saving energy.
}

//Note: These attack and defend functions will vary messages depending on if the ememy is stormtroopers or the emperor,
//but the theme will stay the same.