// CS1300 Spring 2019
// Author: Ethan Schacht
// Recitation: 304 – Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/etsc9287/es_csci1300
// Homework 6 - Problem # 5

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
using namespace std;

//Algorithm: Populate a pair of arrays for titles and authors
    //1. take split function as seen on last week's hw
    //2. Create special conditions of returning -1 or 0 when file doens't open or numBookStored = size.
    //3. After reading file, use split to separate titles and authors
    //4. Create new array of size 2 that stores author and title.
    //5. if the line length is 0, read over that line
    //6. if the line length isn't 0, authors go in element 0 of new array and titles go into element 1
//Input parameters: string fileName, string titles[], string authors[], int numBookStored, int size
//Output: none, stores in titles and authors arrays
//Returns: -1 if file isn't read, -2 if size equals numBooksStored, size of array otherwise

int split (string str, char c, string arr[], int length)
{
    if (str.length() == 0) {
        return 0; //no elements if the string length is 0
    }
    string word;
    int j = 0;
    str = str + c; //adds delimiter to end of string to correctly count number of elements
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == c) 
        {
        	if (word.length() == 0) continue;
        	if (j < length)
        	{
        	    arr[j] = word; //stores split up words in array
        	}
            j++; //count amount of times different split strings of characters occurs, delmiters dismissed as ""
            word = "";
        } 
        else 
        {
            word = word + str[i]; //add characters together if delimiter isn't present
        }
    }
    if (j > length)
    {
        return -1; //return -1 if words exceeds our array length
    }

    return j;
}

int readBooks(string fileName, string titles[], string authors[], int numBookStored, int size)
{
    ifstream fp;
    fp.open(fileName);
    if (fp.is_open())
    {
        string array[2]; //Array of size 2 for author and title
        string line; //represents each line
        int i = numBookStored;
        
        if (numBookStored == size)
        {
            return -2; // special case if books stores equals size of array
        }
        while (getline(fp, line)) //reads all lines in file
        {
            if (i == size)
            {
                return size; //return the size of array when i = size
            }
            
            split(line,',', array, size); //split all lines with delimiter ","
            
            if (line.length() == 0)
            {
                continue; //skip empty lines
            }
            
            if (line.length() != 0)
            {
                authors[i] = array[0]; //add authors and titles to respective positions in arrays
                titles[i] = array[1];
                i++;
            }
        }
        
        return i;

    }
    else
    {
        return -1;
    }
}

int main(){
    
    //test 1
    //expected output
    //10
    //explanation: There are 10 books that can be stored in array
    string authors[10] = {};
    string titles[10] = {};
    int test1 = readBooks("books.txt", titles, authors, 0, 10);
    cout << test1 << endl;
    
    //test 2
    //expected output
    //-2
    //explanation: Size of array is equal to number of books stored
    string authors2[10] = {"Libba Bray"};
    string titles2[10] = {"A Great and Terrible Beauty"};
    int test2 = readBooks("books.txt", titles2, authors2, 1, 1);
    cout << test2 << endl;
    
}