// CS1300 Spring 2019
// Author: Ethan Schacht
// Recitation: 304 – Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/etsc9287/es_csci1300
// Homework 6 - Problem # 4

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//Algorithm: Read from text file, store contents in an array and find amount of contents
    //1. Read file and return -1 if it doesn't open, continue otherwise.
    //2. If a line is empty, continue reading
    //3. Convert the numbers read as strings to integers, accumulate these ints.
    //4. Put the contents in array an return the accumulator;
//Input parameters: filename, array for storage, length of array
//Output: contents of array
//Returns: amount of lines

void printArray(int arr[], int length)
{
    for (int i = 0; i < length; i++)
    {
        cout << arr[i] << endl; //prints all elements of array
    }
}

int getLinesFromFile(string fileName, int arr[], int length)
{
    ifstream fp;
    fp.open(fileName);
    if (fp.is_open())
    {
        string s; //represents a line
        int index = 0;
        
        while (getline(fp, s)) //reads all lines in file
        {
            if (s.length() == 0) 
            {
                continue; //if line is empty, continue reading, not added to array
            }
            if (index < length)
            {
                int number = stoi(s); //converts numbers read as strings to ints
                arr[index] = number;
                index ++; //accumulates # of ints
            }
        }
        fp.close();
        return index;
    }
    else 
    {
        return -1; //error return if file doesn't open properly
    }
    
}

int main() {
    
    int arr[4];
    
    //test 1
    //expected output
    //5
    //1
    //5
    //23
    //45
    //explanation: there are 5 lines in this file and the first 5 lines are 1,5,23,45
    cout << getLinesFromFile("filename.txt", arr, 4) << endl;
    printArray(arr, 4);
    
    cout << "" << endl;
    
    //test 2
    //expected output
    //5
    //1
    //5
    //23
    //45
    //18
    //explanation: there are 5 lines in this file and the first 5 lines are 1,5,23,45,18

    cout << getLinesFromFile("filename.txt", arr, 5) << endl;
    printArray(arr, 5);
    
}