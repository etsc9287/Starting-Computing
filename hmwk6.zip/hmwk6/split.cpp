// CS1300 Spring 2019
// Author: Ethan Schacht
// Recitation: 304 – Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/etsc9287/es_csci1300
// Homework 6 - Problem # 3

#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

//Algorithm: Find amount of lines split by delimiter, create array of all lines
    //1. take split function as seen on last week's hw
    //2. As long as counter is less that length of array, store split up words in array
    //3. if counter exceeds array length, return -1.
//Input parameters: string, delimiyer, array to store strings, length of array
//Output: none
//Returns: amount of lines

int split (string str, char c, string arr[], int length)
{
    if (str.length() == 0) {
        return 0; //no elements if the string length is 0
    }
    string word = "";
    int j = 0;
    str = str + c; //adds delimiter to end of string to correctly count number of elements
    for (int i = 0; i < str.length(); i++)
    {
        if (str[i] == c) 
        {
        	if (word.length() == 0) continue;
        	if (j < length)
        	{
        	    arr[j] = word; //stores split up words in array
        	}
            j++; //count amount of times different split strings of characters occurs, delmiters dismissed as ""
            word = "";
        } 
        else 
        {
            word = word + str[i]; //add characters together if delimiter isn't present
        }
    }
    if (j > length)
    {
        return -1; //return -1 if words exceeds our array length
    }

    return j;
}

int main() {
    
    //test 1
    //expected output
    // 3
    //explanation: 3 elements in this array after separating by delimiters
    string arr[3] = {"cow","dog","pig"};
    int test1 = split("cow//dog//pig", '/', arr, 3);
    cout << test1 << endl;
    
    //test 2
    //expected output
    //4
    //explanation: 4 elements in this array after separating by delimiters
    string arr2[4] = {"cow","dog","pig","llama"};
    int test2 = split("cow,dog,,pig,llama", ',', arr2, 4);
    cout << test2 << endl;
    
    return 0;
}