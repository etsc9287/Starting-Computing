// CS1300 Spring 2019
// Author: Ethan Schacht
// Recitation: 304 – Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/etsc9287/es_csci1300
// Homework 6 - Problem # 2

#include <iostream>
#include <string>
using namespace std;

//Algorithm: Shifts each letter in a message n spaces to the left or right
    //1. declare all arrays including their sizes
    //2. Loop until we hit the size of our arrays
    //3. print respective arrays with cout << arr[index] << endl;
//Input parameters: none
//Output: four arrays
//Returns: none

void floodMap(double map[][4], int rows, double water_level)
{
    int i = 0;
    for (i = 0; i < rows; i++) //outer for loop indexes through all arrays (rows)
    {
        int j = 0;
        for (j = 0; j < 4; j++) //inner for loop indexes through all elements in arrays (columns)
        {
            if (map[i][j] <= water_level) //tests if every element is below or above water level 
            {
                cout << "*";
            }
            else
            {
                cout << "_";
            }
        }
        cout << "\n"; //separates all rows 
    }
    
}
int main(){
    
    //test 1
    //expected output
    //*__*
    //**_*
    double map[2][4] = {{0.2, 0.8, 0.8, 0.2},{0.2, 0.2, 0.8, 0.5}};
    floodMap(map, 2, 0.5);
    
    cout << "" << endl;
    
    //test 2
    //expected output
    //*_**
    //*__*
    //_*__
    //****
    double map2[4][4] = {{1.0, 5.0, 1.0, 1.0},
    {1.0, 5.0, 5.0, 1.0},
    {5.0, 1.0, 5.0, 5.0},
    {1.0, 1.0, 1.0, 1.0}};
    floodMap(map2, 4, 3.14);
    
    
}