// CS1300 Spring 2019
// Author: Ethan Schacht
// Recitation: 304 – Hao
// Cloud9 Workspace Editor Link: https://ide.c9.io/etsc9287/es_csci1300
// Homework 3 - Problem # 1

#include <iostream>
using namespace std;

//Algorithm: Say "Hello, World!" to our user
    //1. Print "Hello, world!"
//Input parameters: none
//Output: "Hello, world!"
//Returns: none

int main() {
    cout << "Hello, world!" << endl; //Prints "Hello, world!"
    
}